window.shaders = window.shaders || {};
window.shaders.fragmentText = `
/**
the fragment shader; determines the color of a pixel
uses info previously computed at each triangle vertex that surrounds the pixel

since the pixel could lie anywhere inside the triangle,
it will receive data as a weighted blend from what was passed on from the surrounding vertices
*/
precision mediump float;
varying vec3 vColor;
uniform float uTime;

void main(void) {
    gl_FragColor = vec4(vColor, 1.0 * sin(uTime));
}
`;