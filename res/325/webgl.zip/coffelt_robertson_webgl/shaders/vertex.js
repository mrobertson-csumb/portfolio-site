window.shaders = window.shaders || {};
window.shaders.vertexText = `
/*
the vertex shader; transforms each vertex from its local space into clip space
also computes and passes other data (like color)

note: this shader only gets information about a single vertex with
      no knowledge of what it is a part of (the triangle).

a stage of the pipeline that receives info about a vertex,
transforms it, and forwards its results to the next stage
(which will start assembling each vertex into the triangles they are composed of).

shader outputs will generally be interpolated (weighted blend) for each pixel inside the triangle and
 received as input to the fragment shader
*/
attribute vec3 aVertexPosition;
attribute vec3 aVertexColor;// #8.1 add vertex color

uniform mat4 uWorldMatrix;
uniform mat4 uViewMatrix;
uniform mat4 uProjectionMatrix;

varying vec3 vColor;

void main(void) {
    // treat the vertex as a point, multiply right to left
    gl_Position = uProjectionMatrix * uViewMatrix * uWorldMatrix * vec4(aVertexPosition, 1.0);

    // #8.2 -- was: vColor = vec3(0.0, 0.0, 0.0);
    vColor = aVertexColor;
}
`;
