let gl;

const START = Date.now();

// The core data associated with the triangle that we will need to render it
let triangleGeometry = {
    worldMatrix: null,       // the matrix that transforms this object from local space to world space
    shaderProgram: null,     // the shader program of "how" to render this object (vertex & fragment)
    positionBuffer: null,    // the buffer that holds all of the position data
    colorBuffer: null,       // the buffer that holds all of the color data
    bufferItemCount: null,   // how many vertices the buffer contains
};

// The core data associated with the line grid that we will need to render it
let lineGridGeometry = {
    worldMatrix: null,      // the matrix that transforms this object from local space to world space
    shaderProgram: null,    // the shader program of "how" to render this object (vertex & fragment)
    positionBuffer: null,   // the buffer that holds all of the position data
    colorBuffer: null,      // the buffer that holds all of the color data
    bufferItemCount: null,  // how many vertices the buffer contains
};

// we preallocate our view-related matrix objects here and reuse them every frame
let viewMatrix = new Matrix4();
let projectionMatrix = new Matrix4();

// the shader that will be used by each piece of geometry (they could each use their own shader but in this case it will be the same)
let shaderProgram;


// -------------------------------------------------------------------------
function initializeAndStartRendering() {
    initGL();

    // #3
    createShaders();

    createTriangleGeometry();

    // bonus
    createLineGridGeometry();

    if (gl) {
        gl.enable(gl.DEPTH_TEST);
        updateAndRender();
    }
}

/**
 * called first and performs one time initialization
 *
 * @param canvas
 */
function initGL(canvas = document.getElementById('webgl-canvas')) {
    try {
        gl = canvas.getContext("webgl");

        // Note: gl does not naturally have canvasWidth or canvasHeight
        // We are attaching them to the object for convenience
        gl.canvasWidth = canvas.width;
        gl.canvasHeight = canvas.height;
    } catch (e) {
    }

    if (!gl) {
        alert("Could not initialise WebGL, sorry :-(");
    }
}

// -------------------------------------------------------------------------
async function createShaders() {
    // #3: get the objects representing individual shaders
    const vertexShaderText = window.shaders.vertexText;
    const fragmentShaderText = window.shaders.fragmentText;

    // console.log(`v: ${vertexShaderText}\nf: ${fragmentShaderText}`);

    // #4: compile and attach shaders
    const vertexShader = createCompiledShader(gl, vertexShaderText, gl.VERTEX_SHADER);
    const fragmentShader = createCompiledShader(gl, fragmentShaderText, gl.FRAGMENT_SHADER);

    // #5 Create an empty gl "program" which will be composed of compiled shaders
    shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);

    // Tell gl it's ready to go, link it
    gl.linkProgram(shaderProgram);
    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
        alert("Could not initialise shaders");
    }

    gl.useProgram(shaderProgram);

    // Here we get references to all of our "attributes" and "uniforms" and store them on the shaderProgram object.
    // Note: the shaderProgram object does not already have these properties, we are attaching them here
    //       for our own convenience / bookkeeping

    shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
    gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

    // #9.1, 9.2 get a reference to aVertexColor, store in shaderProgram.vertexColorAttribute
    shaderProgram.vertexColorAttribute = gl.getAttribLocation(shaderProgram, 'aVertexColor');
    // #9.3 enable the attr
    gl.enableVertexAttribArray(shaderProgram.vertexColorAttribute);

    shaderProgram.worldMatrixUniform = gl.getUniformLocation(shaderProgram, "uWorldMatrix");
    shaderProgram.viewMatrixUniform = gl.getUniformLocation(shaderProgram, "uViewMatrix");
    shaderProgram.projectionMatrixUniform = gl.getUniformLocation(shaderProgram, "uProjectionMatrix");

    shaderProgram.timeUniform = gl.getUniformLocation(shaderProgram, 'uTime');
}

// -------------------------------------------------------------------------
function createCompiledShader(gl, shaderText, shaderType) {
    var shader = gl.createShader(shaderType);

    // #4b complete the shader code
    gl.shaderSource(shader, shaderText);
    gl.compileShader(shader);

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert(gl.getShaderInfoLog(shader));
        console.log(gl.getShaderInfoLog(shader));
        return null;
    }
    return shader;
}

/**
 * creates basic triangle geometry
 */
function createTriangleGeometry() {

    const positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);

    //@formatter:off
    let positions = [
         0.0,  1.0, 0.0, // vertex 1: x, y, z
        -1.0, -1.0, 0.0, // vertex 2: x, y, z
         1.0, -1.0, 0.0  // vertex 3: x, y, z
    ];
    //@formatter:on

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);


    // store a reference to the buffer for render submission
    triangleGeometry.positionBuffer = positionBuffer;

    // #7
    /*
    repeat the process from creating the position buffer -- this time for color.
    consists of 3 colors (9 floats)
    Each color is composed of 3 color channels (RGB) ranging from 0 to 1.
    The first color should be red, the second green, and the third blue.
    Make sure to store a reference to this new buffer on the triangleGeometry object as shown below.
    * */
    // #7.1 create color buffer
    const colorBuffer = gl.createBuffer();

    // #7.2 bind color buffer
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    // #7.3 create color array
    const colors = new Float32Array([
        1.0, 0.0, 0.0,
        0.0, 1.0, 0.0,
        0.0, 0.0, 1.0
    ]);

    // #7.4 "buffer" color data
    gl.bufferData(gl.ARRAY_BUFFER, colors, gl.STATIC_DRAW);

    // #7.5 store a reference to the color buffer on the triangleGeometry object
    triangleGeometry.colorBuffer = colorBuffer;


    // allocate a matrix that we will reuse for this object (situate it in the world)
    triangleGeometry.worldMatrix = new Matrix4();


    // WebGL needs to know how many vertices we have
    triangleGeometry.bufferItemCount = 3;

    // specify the shader which carries the instructions for "how" to render
    triangleGeometry.shaderProgram = shaderProgram;


}


/**
 * called every frame to update our scene and render it
 * on first call, it kicks off the application loop
 * will repeatedly call itself to keep generating frame
 */
function updateAndRender() {
    requestAnimationFrame(updateAndRender);
    let canvas = document.getElementById('webgl-canvas');

    // #2: use entire canvas
    gl.viewport(0, 0, canvas.width, canvas.height); // todo -- one-time setting, move to init?


    // this is a new frame so let's clear out whatever happened last frame
    gl.clearColor(0.707, 0.707, 1, 1.0); // todo -- one-time setting, move to init?
    gl.clear(
        gl.COLOR_BUFFER_BIT |  // color buffer (the one you normally think of)
        gl.DEPTH_BUFFER_BIT    // depth buffer; stores distance from camera the geometry at each pixel is.
    );

    let elapsed = (Date.now() - START) / 1000;

    renderTriangle(elapsed % 6);
    renderLines(elapsed % 6);
}

// -------------------------------------------------------------------------
function renderTriangle(secondsElapsedSinceStart) {

    // #6 -- update triangle geometry world matrix here (used to place the triangle into world space)
    // #6.1 reset the matrix back to identity
    triangleGeometry.worldMatrix.setIdentity();

    // calculate the number of degrees we should have rotated given how much time has elapsed
    // 60 degrees per second
    const degrees = secondsElapsedSinceStart * 60;


    // #11 set the triangle geometry world matrix to be a rotation based on "degrees"
    triangleGeometry.worldMatrix.setRotationY(degrees);
    // console.log(`s: ${degrees}`);

    // #6.2 make it a translation in the -z direction of [0,0,-7]
    triangleGeometry.worldMatrix.translate(0, 0, -7);

    // #6.2b set the projection matrix
    projectionMatrix.setPerspective(
        45,                                 // vertical FOV: 45 degrees
        gl.canvasWidth / gl.canvasHeight,  // aspect ratio: from width & height of the canvas
        0.1,                                // near plane distance: 0.1
        1000                                 // far plane distance: 1000
    );


    gl.bindBuffer(gl.ARRAY_BUFFER, triangleGeometry.positionBuffer);
    gl.vertexAttribPointer(
        triangleGeometry.shaderProgram.vertexPositionAttribute,
        3,
        gl.FLOAT,
        gl.FALSE,
        0, // stride - used for mixing data in a single buffer, ignore
        0  // offset - used for mixing data in a single buffer, ignore
    );

    // #10 - map the color buffer similar to the position buffer above
    gl.bindBuffer(gl.ARRAY_BUFFER, triangleGeometry.colorBuffer);
    gl.vertexAttribPointer(
        triangleGeometry.shaderProgram.vertexColorAttribute,
        3,
        gl.FLOAT,
        gl.FALSE,
        0,
        0
    );

    // Send our matrices to the shader
    gl.uniformMatrix4fv(shaderProgram.worldMatrixUniform, false,
        triangleGeometry.worldMatrix.clone().transpose().elements);
    gl.uniformMatrix4fv(shaderProgram.viewMatrixUniform, false,
        viewMatrix.clone().transpose().elements);
    gl.uniformMatrix4fv(shaderProgram.projectionMatrixUniform, false,
        projectionMatrix.clone().transpose().elements);

    gl.drawArrays(gl.TRIANGLES, 0, triangleGeometry.bufferItemCount);
}

// -------------------------------------------------------------------------
function createLineGridGeometry() {

    const linePosBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, linePosBuffer);

    let linePositions = [];

    // #B1 specify the horizontal lines
    for (let i = -10; i <= 10; ++i) {
        // add position for line start point (x value should be i)
        linePositions.push(i, -1, -10);

        // add position for line end point (x value should be i)
        linePositions.push(i, -1, 10);
    }

    // specify the lateral lines
    for (let i = -10; i <= 10; ++i) {
        // add position for line start point (z value should be i)
        linePositions.push(-10, -1, i);

        // add position for line end point (z value should be i)
        linePositions.push(10, -1, i);
    }

    console.log(`lines: ${linePositions}`);

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(linePositions), gl.STATIC_DRAW);


    const lineColorBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, lineColorBuffer);

    let lineColors = [];
    for (let i = 0; i < linePositions.length / 3; ++i) {
        lineColors.push.apply(lineColors, [0, 0, 0]);
    }

    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(lineColors), gl.STATIC_DRAW);

    lineGridGeometry.positionBuffer = linePosBuffer;
    lineGridGeometry.colorBuffer = lineColorBuffer;
    lineGridGeometry.bufferItemCount = 2 * 21 * 2;

    // allocate a matrix that we will reuse for this object (situate it in the world)
    lineGridGeometry.worldMatrix = new Matrix4();

    // specify the shader which carries the instructions for "how" to render
    lineGridGeometry.shaderProgram = shaderProgram;

}

// -------------------------------------------------------------------------
function renderLines(secondsElapsedSinceStart) {
    // reset the matrix back to identity
    lineGridGeometry.worldMatrix.setIdentity();

    // no rotation required

    // translation in the -z direction of [0,0,-7]
    lineGridGeometry.worldMatrix.translate(0, 0, -7);

    // set the projection matrix (move to common?)
    projectionMatrix.setPerspective(
        45,                                 // vertical FOV: 45 degrees
        gl.canvasWidth / gl.canvasHeight,  // aspect ratio: from width & height of the canvas
        0.1,                                // near plane distance: 0.1
        1000                                 // far plane distance: 1000
    );

    gl.bindBuffer(gl.ARRAY_BUFFER, lineGridGeometry.positionBuffer);
    gl.vertexAttribPointer(
        lineGridGeometry.shaderProgram.vertexPositionAttribute,
        3,
        gl.FLOAT,
        gl.FALSE,
        0, // stride - used for mixing data in a single buffer, ignore
        0  // offset - used for mixing data in a single buffer, ignore
    );

    /// color
    gl.bindBuffer(gl.ARRAY_BUFFER, lineGridGeometry.colorBuffer);
    gl.vertexAttribPointer(
        lineGridGeometry.shaderProgram.vertexColorAttribute,
        3,
        gl.FLOAT,
        gl.FALSE,
        0,
        0
    );

    // // send matrices to the shader
    gl.uniformMatrix4fv(shaderProgram.worldMatrixUniform, false,
        lineGridGeometry.worldMatrix.clone().transpose().elements);

    // below is done for you, uncomment when ready
    gl.uniform1f(shaderProgram.timeUniform, secondsElapsedSinceStart);
    //
    gl.drawArrays(gl.LINES, 0, lineGridGeometry.bufferItemCount);
    // console.log(`t: ${secondsElapsedSinceStart}, sin(t): ${Math.abs(Math.sin(secondsElapsedSinceStart))}`);
}