'use strict';
/**
 * @author Matthew Robertson
 */

let gl;

const time = new Time();
const camera = new OrbitCamera();

let starfield = null;
const STARFIELD_SIZE = 10.0;

let sun = null;
const SUN_SIZE = 0.4;
const SUN_ROTATION_RATE = 0.075;

let earth = null;
const EARTH_SIZE = 0.2;
const EARTH_ROTATION_RATE = 10;

let earthOrbit = null;
const EARTH_ORBIT_DIST = 80;
const EARTH_ORBIT_RATE = 1 / 3.654;


let moon = null;
const MOON_SIZE = 0.075;
const MOON_ROTATION_RATE = 2.0; // IRL this is 0, but requirements..

let moonOrbit = null;
const MOON_ORBIT_DIST = 15;
const MOON_ORBIT_RATE = 1 / 0.27;


const projectionMatrix = new Matrix4();

let diffuseShaderProgram;
let emissiveShaderProgram;

// start app when page ready
window.onload = window['initializeAndStartRendering'];

let loadedAssets = {
    sphereJSON: null,
    emissiveVS: null,
    emissiveFS: null,
    diffuseVS: null,
    diffuseFS: null,
    starFieldImage: null,
    sunImage: null,
    earthImage: null,
    moonImage: null
};

function loadAssets(onLoadedCB) {
    const files = [
        fetch('./data/sphere.json').then(r => r.json()),
        fetch('./shaders/emissive-vs.glsl').then(r => r.text()),
        fetch('./shaders/emissive-fs.glsl').then(r => r.text()),
        fetch('./shaders/diffuse-vs.glsl').then(r => r.text()),
        fetch('./shaders/diffuse-fs.glsl').then(r => r.text()),
        loadImage('./data/stars.jpg'),
        loadImage('./data/sun.jpg'),
        loadImage('./data/earth.jpg'),
        loadImage('./data/moon.png'),
    ];

    Promise.all(files).then(fs => [
            loadedAssets.sphereJSON,
            loadedAssets.emissiveVS,
            loadedAssets.emissiveFS,
            loadedAssets.diffuseVS,
            loadedAssets.diffuseFS,
            loadedAssets.starFieldImage,
            loadedAssets.sunImage,
            loadedAssets.earthImage,
            loadedAssets.moonImage
        ] = fs
    ).catch(function (error) {
        console.error(error.message);
    }).finally(function () {
        onLoadedCB();
    });
}

function initializeAndStartRendering() {
    initGL();
    loadAssets(function () {
        createShaders(loadedAssets);
        createScene();

        updateAndRender();
    });
}

function initGL(canvas = document.getElementById("webgl-canvas")) {
    try {
        gl = canvas.getContext("webgl");
        gl.canvasWidth = canvas.width;
        gl.canvasHeight = canvas.height;

        gl.enable(gl.DEPTH_TEST);
    } catch (e) {
    }

    if (!gl) {
        alert("Could not initialise WebGL, sorry :-(");
    }
}


function createShaders(loadedAssets) {
    //// diffuse shader settings
    diffuseShaderProgram = createCompiledAndLinkedShaderProgram(loadedAssets.diffuseVS, loadedAssets.diffuseFS);

    diffuseShaderProgram.attributes = {
        vertexPositionAttribute: gl.getAttribLocation(diffuseShaderProgram, "aVertexPosition"),
        vertexNormalsAttribute: gl.getAttribLocation(diffuseShaderProgram, "aNormal"),
        vertexTexcoordsAttribute: gl.getAttribLocation(diffuseShaderProgram, "aTexcoords")
    };

    diffuseShaderProgram.uniforms = {
        worldMatrixUniform: gl.getUniformLocation(diffuseShaderProgram, "uWorldMatrix"),
        viewMatrixUniform: gl.getUniformLocation(diffuseShaderProgram, "uViewMatrix"),
        projectionMatrixUniform: gl.getUniformLocation(diffuseShaderProgram, "uProjectionMatrix"),
        textureUniform: gl.getUniformLocation(diffuseShaderProgram, "uTexture")
    };

    //// emissive shader settings
    emissiveShaderProgram = createCompiledAndLinkedShaderProgram(loadedAssets.emissiveVS, loadedAssets.emissiveFS);

    emissiveShaderProgram.attributes = {
        vertexPositionAttribute: gl.getAttribLocation(emissiveShaderProgram, "aVertexPosition"),
        vertexTexcoordsAttribute: gl.getAttribLocation(emissiveShaderProgram, "aTexcoords")
    };

    emissiveShaderProgram.uniforms = {
        worldMatrixUniform: gl.getUniformLocation(emissiveShaderProgram, "uWorldMatrix"),
        viewMatrixUniform: gl.getUniformLocation(emissiveShaderProgram, "uViewMatrix"),
        projectionMatrixUniform: gl.getUniformLocation(emissiveShaderProgram, "uProjectionMatrix"),
        textureUniform: gl.getUniformLocation(emissiveShaderProgram, "uTexture")
    };
}

function createScene() {
    sun = new WebGLGeometryJSON(gl);
    sun.create(loadedAssets.sphereJSON, loadedAssets.sunImage);

    earth = new WebGLGeometryJSON(gl);
    earth.create(loadedAssets.sphereJSON, loadedAssets.earthImage);

    moon = new WebGLGeometryJSON(gl);
    moon.create(loadedAssets.sphereJSON, loadedAssets.moonImage);

    starfield = new WebGLGeometryJSON(gl);
    starfield.create(loadedAssets.sphereJSON, loadedAssets.starFieldImage);


    // scale objects
    starfield.worldMatrix.scale(STARFIELD_SIZE, STARFIELD_SIZE, STARFIELD_SIZE);
    sun.worldMatrix.scale(SUN_SIZE, SUN_SIZE, SUN_SIZE);
    earth.worldMatrix.scale(EARTH_SIZE, EARTH_SIZE, EARTH_SIZE);
    moon.worldMatrix.scale(MOON_SIZE, MOON_SIZE, MOON_SIZE);

    // setup orbits
    earthOrbit = new Matrix4().translate(EARTH_ORBIT_DIST, 0, 0);
    earth.worldMatrix.applyTransform(earthOrbit);

    moonOrbit = new Matrix4().translate(MOON_ORBIT_DIST, 0, 0);
    moon.worldMatrix.applyTransform(moonOrbit);  // moon orbits earth
    moon.worldMatrix.applyTransform(earthOrbit); // moon's orbit depends on earth's orbit
}

function updateAndRender() {
    requestAnimationFrame(updateAndRender);

    time.update();
    camera.update(time.deltaTime);

    //todo: using only world matrix seems incorrect, but it's working..
    sun.worldMatrix.rotateY(SUN_ROTATION_RATE);

    //// rotate earth & moon along orbits
    // negate orbits for so rotation can be applied independently
    earth.worldMatrix.negateTransform(earthOrbit);
    moon.worldMatrix.negateTransform(earthOrbit);
    moon.worldMatrix.negateTransform(moonOrbit);

    // apply rotation
    earth.worldMatrix.rotateY(EARTH_ROTATION_RATE);
    moon.worldMatrix.rotateY(MOON_ROTATION_RATE);

    // update orbits
    earthOrbit.rotateY(EARTH_ORBIT_RATE);
    moonOrbit.rotateY(MOON_ORBIT_RATE);

    // apply orbits
    earth.worldMatrix.applyTransform(earthOrbit);
    moon.worldMatrix.applyTransform(moonOrbit);  // moon orbits earth
    moon.worldMatrix.applyTransform(earthOrbit); // moon's orbit depends on earth's orbit

    //// rendering & prep
    gl.viewport(0, 0, gl.canvasWidth, gl.canvasHeight);

    // clear frame
    gl.clearColor(0.777, 0.777, 0.777, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // camera view variables
    projectionMatrix.setPerspective(45, (gl.canvasWidth / gl.canvasHeight), 0.1, 1000);

    // actually render
    starfield.render(camera, projectionMatrix, emissiveShaderProgram);
    sun.render(camera, projectionMatrix, emissiveShaderProgram);
    earth.render(camera, projectionMatrix, diffuseShaderProgram);
    moon.render(camera, projectionMatrix, diffuseShaderProgram);
}