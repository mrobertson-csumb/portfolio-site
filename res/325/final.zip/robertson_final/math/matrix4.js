/**
 * An object representing a 4x4 matrix
 *
 * by array position
 *   00  01  02  03
 *   04  05  06  07
 *   08  09  10  11
 *   12  13  14  15
 *
 * by row/column
 *   11  12  13  14
 *   21  22  23  24
 *   31  32  33  34
 *   41  42  43  44
 *
 * @param x not used
 * @param y not used
 * @param z not used
 * @returns {Matrix4}
 * @constructor
 */
const Matrix4 = function (x = null, y = null, z = null) {
    this.elements = new Float32Array(16);

    if (!(this instanceof Matrix4)) {
        alert("Matrix4 constructor must be called with the new operator");
        console.log(`x: ${x}, y: ${y}, z: ${z}`);
    }

    /**
     * creates and returns a new Matrix4 instance that is an exact copy of 'this'
     *
     * @returns {Matrix4}
     */
    this.clone = function () {
        const newMatrix = new Matrix4();
        for (let i = 0; i < 16; ++i) {
            newMatrix.elements[i] = this.elements[i];
        }
        return newMatrix;
    };

    /**
     * copies all of the elements of other into the elements of 'this' matrix
     *
     * @param m the matrix to copy into this matrix
     * @returns {Matrix4}
     */
    this.copy = function (m) {
        for (let i = 0; i < 16; ++i) {
            this.elements[i] = m.elements[i];
        }

        return this;
    };

    /**
     * replaces all values in this matrix with those given
     *
     * @params n11 .. n44 matrix entries
     * @returns {Matrix4}
     */
    this.set = function (n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44) {
        this.elements = [...arguments];

        return this;
    };

    /**
     * set every element of this matrix to be a rotation around the x-axis
     *
     * @param degrees amount of rotation
     * @returns {Matrix4}
     */
    this.setRotationX = function (degrees) {
        const radians = degrees * Math.PI / 180;

        const c = Math.cos(radians);
        const s = Math.sin(radians);

        this.elements = [
            1, 0, 0, 0,
            0, c, -s, 0,
            0, s, c, 0,
            0, 0, 0, 1

        ];

        return this;
    };

    /**
     * set every element of this matrix to be a rotation around the y-axis
     * @param degrees amount of rotation
     * @returns {Matrix4}
     */
    this.setRotationY = function (degrees) {
        const radians = degrees * Math.PI / 180;
        const c = Math.cos(radians);
        const s = Math.sin(radians);

        this.elements = [
            c, 0, s, 0,
            0, 1, 0, 0,
            -s, 0, c, 0,
            0, 0, 0, 1
        ];

        return this;
    };

    this.setRotationZ = function (degrees) {
        const radians = degrees * Math.PI / 180;
        const c = Math.cos(radians);
        const s = Math.sin(radians);

        this.elements = [
            c, -s, 0, 0,
            s, c, 0, 0,
            0, 0, 1, 0,
            0, 0, 0, 1,
        ];

        return this;
    };

    /**
     * apply an X rotation transform to this matrix
     * for convenience
     * @param degrees degrees of rotation from current position
     * @returns {Matrix4} this matrix after rotation
     */
    this.rotateX = degrees => {
        this.copy(new Matrix4().setRotationX(degrees).multiplyRightSide(this));
        return this;

    };

    /**
     * apply a Y rotation transform to this matrix
     * for convenience
     * @param degrees degrees of rotation from current position
     * @returns {Matrix4} this matrix after rotation
     */
    this.rotateY = degrees => {
        this.copy(new Matrix4().setRotationY(degrees).multiplyRightSide(this));
        return this;

    };

    /**
     * apply a Z rotation transform to this matrix
     * for convenience
     * @param degrees degrees of rotation from current position
     * @returns {Matrix4} this matrix after rotation
     */
    this.rotateZ = degrees => {
        this.copy(new Matrix4().setRotationZ(degrees).multiplyRightSide(this));
        return this;
    };


    /**
     * negate a matrix transform by applying its inverse
     * for convenience
     * @param otherMatrix the matrix to negate
     * @returns {Matrix4} this matrix after the negation (transform)
     */
    this.negateTransform = otherMatrix => {
        this.copy(otherMatrix.clone().inverse().multiplyRightSide(this));
        return this;
    };


    /**
     * apply another matrix to transform this one
     * for convenience
     * @param otherMatrix the matrix to apply
     * @returns {Matrix4} this matrix after the transform
     */
    this.applyTransform = otherMatrix => {
        this.copy(otherMatrix.clone().multiplyRightSide(this));
        return this;
    };

    /**
     * orient this matrix such that
     * it's eye pos is pointed directly at the target
     * and it is facing upward
     * for convenience
     * @param eyePos the vector representing the eye's position
     * @param targetPos the vector representing the target
     * @param worldUp the vector represneting up (the top) for the this
     * @returns {Matrix4} this rotated such that it is looking at the target
     */
    this.setLookAt = function (eyePos, targetPos, worldUp) {
        this.identity();
        const e = eyePos;                                         // eye
        const f = targetPos.clone().subtract(eyePos).normalize(); // forward
        const r = f.normalized().cross(worldUp).normalize();      // right
        const u = r.cross(f);                                     // up

        this.elements = [
            r.x, u.x, -f.x, e.x,
            r.y, u.y, -f.y, e.y,
            r.z, u.z, -f.z, e.z,
            0, 0, 0, 1
        ];

        return this;
    };

    /**
     * make the matrix into a pure perspective projection.
     *
     * @param fovy vertical field of view
     * @param aspect aspect ration (w/h)
     * @param near distance to the near plane
     * @param far distance to the far plane
     * @returns {Matrix4} this
     */
    this.setPerspective = function (fovy, aspect, near, far) {
        const fovyRads = (Math.PI / 180) * fovy;
        const n = near;
        const f = far;
        const t = near * Math.tan(fovyRads / 2);
        const r = t * aspect;

        //@formatter:off
        this.elements = [
            n / r,   0  ,          0        ,           0,
             0   , n / t,          0        ,           0,
             0   ,   0  , -(f + n) / (f - n), (-2 * n * f) / (f - n),
             0   ,   0  ,         -1        ,           0
        ];
        //@formatter:on

        return this;
    };

    /**
     * adds a translation to the current matrix
     *
     * @param arg1 either a {Vector3} or the x-component of a vector
     * @param arg2 optional the y-component of a vector
     * @param arg3 optional the z-component of a vector
     * @returns {Matrix4}
     */
    this.translate = function (arg1, arg2, arg3) {
        if (arg1 instanceof Vector3) {
            this.elements[3] += arg1.x;
            this.elements[7] += arg1.y;
            this.elements[11] += arg1.z;
        } else {
            this.elements[3] += arg1;
            this.elements[7] += arg2;
            this.elements[11] += arg3;
        }
        return this;
    };

    /**
     * scales 'this' matrix (on the left) with the given vector components (on the right)
     *
     * @param x vector x-component
     * @param y vector y-component
     * @param z vector z-component
     * @returns {Matrix4}
     */
    this.scale = function (x, y, z) {
        const scaleMatrix = new Matrix4();
        scaleMatrix.elements[0] *= x;
        scaleMatrix.elements[5] *= y;
        scaleMatrix.elements[10] *= z;

        this.multiplyRightSide(scaleMatrix);
        return this;
    };

    /**
     * reset every element in 'this' matrix to make it the identity matrix
     *
     *   1  0  0  0
     *   0  1  0  0
     *   0  0  1  0
     *   0  0  0  1
     *
     * @returns {Matrix4}
     */
    this.identity = function () {
        this.set(
            1, 0, 0, 0,
            0, 1, 0, 0,
            0, 0, 1, 0,
            0, 0, 0, 1
        );
        return this;
    };

    /**
     * multiplies every element in 'this' matrix by a scalar
     *
     * @param s the scalar multiplier
     * @returns {Matrix4}
     */
    this.multiplyScalar = function (s) {
        for (let i = 0; i < 16; ++i) {
            this.elements[i] = this.elements[i] * s;
        }
    };

    /**
     * multiplies 'this' matrix (on the left) by otherMatrixOnRight (on the right)
     * results are applied to the elements on 'this' matrix
     *
     * @param otherMatrix4 the matrix on the right
     * @returns {Matrix4}
     */
    this.multiplyRightSide = function (otherMatrix4) {
        // shorthand
        const e = this.elements;
        const o = otherMatrix4.elements;

        const m11 = e[0] * o[0] + e[1] * o[4] + e[2] * o[8] + e[3] * o[12];
        const m12 = e[0] * o[1] + e[1] * o[5] + e[2] * o[9] + e[3] * o[13];
        const m13 = e[0] * o[2] + e[1] * o[6] + e[2] * o[10] + e[3] * o[14];
        const m14 = e[0] * o[3] + e[1] * o[7] + e[2] * o[11] + e[3] * o[15];

        const m21 = e[4] * o[0] + e[5] * o[4] + e[6] * o[8] + e[7] * o[12];
        const m22 = e[4] * o[1] + e[5] * o[5] + e[6] * o[9] + e[7] * o[13];
        const m23 = e[4] * o[2] + e[5] * o[6] + e[6] * o[10] + e[7] * o[14];
        const m24 = e[4] * o[3] + e[5] * o[7] + e[6] * o[11] + e[7] * o[15];

        const m31 = e[8] * o[0] + e[9] * o[4] + e[10] * o[8] + e[11] * o[12];
        const m32 = e[8] * o[1] + e[9] * o[5] + e[10] * o[9] + e[11] * o[13];
        const m33 = e[8] * o[2] + e[9] * o[6] + e[10] * o[10] + e[11] * o[14];
        const m34 = e[8] * o[3] + e[9] * o[7] + e[10] * o[11] + e[11] * o[15];

        const m41 = e[12] * o[0] + e[13] * o[4] + e[14] * o[8] + e[15] * o[12];
        const m42 = e[12] * o[1] + e[13] * o[5] + e[14] * o[9] + e[15] * o[13];
        const m43 = e[12] * o[2] + e[13] * o[6] + e[14] * o[10] + e[15] * o[14];
        const m44 = e[12] * o[3] + e[13] * o[7] + e[14] * o[11] + e[15] * o[15];

        this.set(m11, m12, m13, m14, m21, m22, m23, m24, m31, m32, m33, m34, m41, m42, m43, m44);

        return this;
    };

    /**
     * computes and returns the determinant for 'this' matrix
     *
     * @returns {number}
     */
    this.determinant = function () {
        const e = this.elements;

        // laid out for clarity, not performance
        const m11 = e[0];
        const m12 = e[1];
        const m13 = e[2];
        const m14 = e[3];
        const m21 = e[4];
        const m22 = e[5];
        const m23 = e[6];
        const m24 = e[7];
        const m31 = e[8];
        const m32 = e[8];
        const m33 = e[9];
        const m34 = e[10];
        const m41 = e[12];
        const m42 = e[13];
        const m43 = e[14];
        const m44 = e[15];

        const det11 = m11 * (m22 * (m33 * m44 - m34 * m43) +
            m23 * (m34 * m42 - m32 * m44) +
            m24 * (m32 * m43 - m33 * m42));

        const det12 = -m12 * (m21 * (m33 * m44 - m34 * m43) +
            m23 * (m34 * m41 - m31 * m44) +
            m24 * (m31 * m43 - m33 * m41));

        const det13 = m13 * (m21 * (m32 * m44 - m34 * m42) +
            m22 * (m34 * m41 - m31 * m44) +
            m24 * (m31 * m42 - m32 * m41));

        const det14 = -m14 * (m21 * (m32 * m43 - m33 * m42) +
            m22 * (m33 * m41 - m31 * m43) +
            m23 * (m31 * m42 - m32 * m41));

        return det11 + det12 + det13 + det14;
    };

    /**
     * modifies 'this' matrix so that it becomes its transpose
     *
     * @returns {Matrix4}
     */
    this.transpose = function () {
        const te = this.elements;
        let tmp;

        tmp = te[1];
        te[1] = te[4];
        te[4] = tmp;
        tmp = te[2];
        te[2] = te[8];
        te[8] = tmp;
        tmp = te[6];
        te[6] = te[9];
        te[9] = tmp;

        tmp = te[3];
        te[3] = te[12];
        te[12] = tmp;
        tmp = te[7];
        te[7] = te[13];
        te[13] = tmp;
        tmp = te[11];
        te[11] = te[14];
        te[14] = tmp;

        return this;
    };

    /**
     * given a row and column,
     * returns the corresponding matrix element's value
     *
     * @param row the matrix row
     * @param col the matrix column
     * @returns {number}
     */
    this.getElement = function (row, col) {
        return this.elements[row * 4 + col];
    };

    /**
     * modifies 'this' matrix so that it becomes its inverse
     *
     * @returns {Matrix4|*}
     */
    this.inverse = function () {
        // based on http://www.euclideanspace.com/maths/algebra/matrix/functions/inverse/fourD/index.htm
        const te = this.elements,
            me = this.clone().elements,

            n11 = me[0], n21 = me[1], n31 = me[2], n41 = me[3],
            n12 = me[4], n22 = me[5], n32 = me[6], n42 = me[7],
            n13 = me[8], n23 = me[9], n33 = me[10], n43 = me[11],
            n14 = me[12], n24 = me[13], n34 = me[14], n44 = me[15],

            t11 = n23 * n34 * n42 - n24 * n33 * n42 + n24 * n32 * n43 - n22 * n34 * n43 - n23 * n32 * n44 + n22 * n33 * n44,
            t12 = n14 * n33 * n42 - n13 * n34 * n42 - n14 * n32 * n43 + n12 * n34 * n43 + n13 * n32 * n44 - n12 * n33 * n44,
            t13 = n13 * n24 * n42 - n14 * n23 * n42 + n14 * n22 * n43 - n12 * n24 * n43 - n13 * n22 * n44 + n12 * n23 * n44,
            t14 = n14 * n23 * n32 - n13 * n24 * n32 - n14 * n22 * n33 + n12 * n24 * n33 + n13 * n22 * n34 - n12 * n23 * n34;

        const det = n11 * t11 + n21 * t12 + n31 * t13 + n41 * t14;

        if (det === 0) {
            console.warn("can't invert matrix, determinant is 0");
            return this.identity();
        }

        const detInv = 1 / det;

        te[0] = t11 * detInv;
        te[1] = (n24 * n33 * n41 - n23 * n34 * n41 - n24 * n31 * n43 + n21 * n34 * n43 + n23 * n31 * n44 - n21 * n33 * n44) * detInv;
        te[2] = (n22 * n34 * n41 - n24 * n32 * n41 + n24 * n31 * n42 - n21 * n34 * n42 - n22 * n31 * n44 + n21 * n32 * n44) * detInv;
        te[3] = (n23 * n32 * n41 - n22 * n33 * n41 - n23 * n31 * n42 + n21 * n33 * n42 + n22 * n31 * n43 - n21 * n32 * n43) * detInv;

        te[4] = t12 * detInv;
        te[5] = (n13 * n34 * n41 - n14 * n33 * n41 + n14 * n31 * n43 - n11 * n34 * n43 - n13 * n31 * n44 + n11 * n33 * n44) * detInv;
        te[6] = (n14 * n32 * n41 - n12 * n34 * n41 - n14 * n31 * n42 + n11 * n34 * n42 + n12 * n31 * n44 - n11 * n32 * n44) * detInv;
        te[7] = (n12 * n33 * n41 - n13 * n32 * n41 + n13 * n31 * n42 - n11 * n33 * n42 - n12 * n31 * n43 + n11 * n32 * n43) * detInv;

        te[8] = t13 * detInv;
        te[9] = (n14 * n23 * n41 - n13 * n24 * n41 - n14 * n21 * n43 + n11 * n24 * n43 + n13 * n21 * n44 - n11 * n23 * n44) * detInv;
        te[10] = (n12 * n24 * n41 - n14 * n22 * n41 + n14 * n21 * n42 - n11 * n24 * n42 - n12 * n21 * n44 + n11 * n22 * n44) * detInv;
        te[11] = (n13 * n22 * n41 - n12 * n23 * n41 - n13 * n21 * n42 + n11 * n23 * n42 + n12 * n21 * n43 - n11 * n22 * n43) * detInv;

        te[12] = t14 * detInv;
        te[13] = (n13 * n24 * n31 - n14 * n23 * n31 + n14 * n21 * n33 - n11 * n24 * n33 - n13 * n21 * n34 + n11 * n23 * n34) * detInv;
        te[14] = (n14 * n22 * n31 - n12 * n24 * n31 - n14 * n21 * n32 + n11 * n24 * n32 + n12 * n21 * n34 - n11 * n22 * n34) * detInv;
        te[15] = (n12 * n23 * n31 - n13 * n22 * n31 + n13 * n21 * n32 - n11 * n23 * n32 - n12 * n21 * n33 + n11 * n22 * n33) * detInv;

        return this;
    };

    /**
     * logs the current matrix values
     *
     * @returns {Matrix4}
     */
    this.log = function () {
        const te = this.elements;
        console.log('[ ' +
            '\n ' + te[0] + ', ' + te[1] + ', ' + te[2] + ', ' + te[3] +
            '\n ' + te[4] + ', ' + te[5] + ', ' + te[6] + ', ' + te[7] +
            '\n ' + te[8] + ', ' + te[9] + ', ' + te[10] + ', ' + te[11] +
            '\n ' + te[12] + ', ' + te[13] + ', ' + te[14] + ', ' + te[15] +
            '\n]'
        );

        return this;
    };

    return this.identity();
};
