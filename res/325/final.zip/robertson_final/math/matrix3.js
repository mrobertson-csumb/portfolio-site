/**
 * An object representing a 3x3 matrix
 *
 * by array position
 *    0   1   2
 *    3   4   5
 *    6   7   8
 *
 * by row/column
 *   11  12  13
 *   21  22  23
 *   31  32  33
 *
 * @constructor
 */
const Matrix3 = function () {

    // Stores a matrix in a flat array, see the "set" function for an example of the layout
    // This format will be similar to what we'll eventually need when feeding this to WebGL
    this.elements = new Float32Array(9);

    if (!(this instanceof Matrix3)) {
        alert("Matrix3 constructor must be called with the new operator");
    }

    /**
     * creates and returns a new Matrix3 instance that is an exact copy of 'this'
     *
     * @returns {Matrix3}
     */
    this.clone = function () {
        const newMatrix = new Matrix3();
        for (let i = 0; i < 9; ++i) {
            newMatrix.elements[i] = this.elements[i];
        }
        return newMatrix;
    };

    /**
     * copies all of the elements of other into the elements of 'this' matrix
     *
     * @param other the matrix to copy into this matrix
     * @returns {Matrix3}
     */
    this.copy = function (other) {
        for (let i = 0; i < 16; ++i) {
            this.elements[i] = other.elements[i];
        }

        return this;
    };

    /**
     * replaces all values in this matrix with those given
     *
     * @params e11 .. e33
     * @returns {Matrix3}
     */
    this.set = function (e11, e12, e13, e21, e22, e23, e31, e32, e33) {
        this.elements = [...arguments];
        return this;
    };

    /**
     * given a row and column,
     * returns the corresponding matrix element's value
     *
     * @param row the matrix row
     * @param col the matrix column
     * @returns {number}
     */
    this.getElement = function (row, col) {
        return this.elements[3 * row + col];
    };

    /**
     * reset every element in 'this' matrix to make it the identity matrix
     *
     *   1  0  0
     *   0  1  0
     *   0  0  1
     *
     * @returns {Matrix3}
     */
    this.identity = function () {
        this.set(
            1, 0, 0,
            0, 1, 0,
            0, 0, 1
        );
        return this;
    };

    /**
     * set every element of this matrix to be a rotation around the x-axis
     * @param degrees amount of rotation
     *
     * @param degrees
     * @returns {Matrix3}
     */
    this.setRotationX = function (degrees) {
        const radians = degrees * Math.PI / 180;
        const c = Math.cos(radians);
        const s = Math.sin(radians);

        this.elements = [
            1, 0, 0,
            0, c, -s,
            0, s, c
        ];

        return this;
    };

    /**
     * set every element of this matrix to be a rotation around the y-axis
     *
     * @param degrees amount of rotation
     * @returns {Matrix3}
     */
    this.setRotationY = function (degrees) {
        const radians = degrees * Math.PI / 180;
        const c = Math.cos(radians);
        const s = Math.sin(radians);

        this.elements = [
            c, 0, s,
            0, 1, 0,
            -s, 0, c
        ];

        return this;
    };

    /**
     * set every element of this matrix to be a rotation around the z-axis
     *
     * @param degrees amount of rotation
     * @returns {Matrix3}
     */
    this.setRotationZ = function (degrees) {
        const radians = degrees * Math.PI / 180;
        const c = Math.cos(radians);
        const s = Math.sin(radians);

        this.elements = [
            c, -s, 0,
            s, c, 0,
            0, 0, 1
        ];

        return this;
    };

    /**
     * multiplies every element in 'this' matrix by a scalar
     *
     * @param s the scalar multiplier
     * @returns {Matrix3}
     */
    this.multiplyScalar = function (s) {
        for (let i = 0; i < 16; ++i) {
            this.elements[i] = this.elements[i] * s;
        }
    };

    /**
     * multiplies 'this' matrix (on the left) by otherMatrixOnRight (on the right)
     * results are applied to the elements on 'this' matrix
     *
     * @param otherMatrixOnRight the matrix on the right
     * @returns {Matrix3}
     */
    this.multiplyRightSide = function (otherMatrixOnRight) {
        // shorthand
        const e = this.elements;
        const o = otherMatrixOnRight.elements;

        const m11 = e[0] * o[0] + e[1] * o[3] + e[2] * o[6];
        const m12 = e[0] * o[1] + e[1] * o[4] + e[2] * o[7];
        const m13 = e[0] * o[2] + e[1] * o[5] + e[2] * o[8];

        const m21 = e[3] * o[0] + e[4] * o[3] + e[5] * o[6];
        const m22 = e[3] * o[1] + e[4] * o[4] + e[5] * o[7];
        const m23 = e[3] * o[2] + e[4] * o[5] + e[5] * o[8];

        const m31 = e[6] * o[0] + e[7] * o[3] + e[8] * o[6];
        const m32 = e[6] * o[1] + e[7] * o[4] + e[8] * o[7];
        const m33 = e[6] * o[2] + e[7] * o[5] + e[8] * o[8];

        this.set(m11, m12, m13, m21, m22, m23, m31, m32, m33);

        return this;
    };

    /**
     * multiplies this matrix with a vector
     * results are applied to the elements on 'this' matrix
     *
     * @param vector the vector on the right
     *
     * @note this was not in the original matrix3
     */
    this.multiplyVector = function (vector) {
        // shorthand
        const te = this.elements;
        const clone = vector.clone();
        vector.x = te[0] * clone.x + te[1] * clone.y + te[2] * clone.z;
        vector.y = te[3] * clone.x + te[4] * clone.y + te[5] * clone.z;
        vector.z = te[6] * clone.x + te[7] * clone.y + te[8] * clone.z;
    };

    /**
     * computes and returns the determinant for 'this' matrix
     *
     * @returns {number}
     */
    this.determinant = function () {
        const e = this.elements;

        // laid out for clarity, not performance
        const m11 = e[0];
        const m12 = e[1];
        const m13 = e[2];
        const m21 = e[3];
        const m22 = e[4];
        const m23 = e[5];
        const m31 = e[6];
        const m32 = e[7];
        const m33 = e[8];

        const minor11 = m22 * m33 - m23 * m32;
        const minor12 = m21 * m33 - m23 * m31;
        const minor13 = m21 * m32 - m22 * m31;

        return m11 * minor11 - m12 * minor12 + m13 * minor13;
    };

    /**
     * modifies 'this' matrix so that it becomes its transpose
     *
     * @returns {Matrix3}
     */
    this.transpose = function () {
        const e = this.elements;
        let tmp;

        tmp = e[1];
        e[1] = e[3];
        e[3] = tmp;
        tmp = e[2];
        e[2] = e[6];
        e[6] = tmp;
        tmp = e[5];
        e[5] = e[7];
        e[7] = tmp;

        return this;
    };

    /**
     * modifies 'this' matrix so that it becomes its inverse
     *
     * @returns {void|Matrix3}
     */
    this.inverse = function () {
        const FLOAT32_EPSILON = 1.1920928955078125e-7;
        const det = this.determinant();
        if (Math.abs(det) <= FLOAT32_EPSILON) {
            return this.identity();
        } else {
            const e = this.elements;

            // laid out for clarity, not performance
            const m11 = e[0];
            const m12 = e[1];
            const m13 = e[2];
            const m21 = e[3];
            const m22 = e[4];
            const m23 = e[5];
            const m31 = e[6];
            const m32 = e[7];
            const m33 = e[8];

            const minor11 = m22 * m33 - m23 * m32;
            const minor12 = m21 * m33 - m23 * m31;
            const minor13 = m21 * m32 - m22 * m31;
            const minor21 = m12 * m33 - m13 * m32;
            const minor22 = m11 * m33 - m13 * m31;
            const minor23 = m11 * m32 - m12 * m31;
            const minor31 = m12 * m23 - m13 * m22;
            const minor32 = m11 * m33 - m13 * m31;
            const minor33 = m11 * m22 - m12 * m21;

            return this.set(
                minor11, -minor21, minor31,
                -minor12, minor22, -minor32,
                minor13, -minor23, minor33
            ).multiplyScalar(1 / det);
        }
    };

    /**
     * logs the current matrix values
     *
     * @returns {Matrix3}
     */
    this.log = function () {
        const e = this.elements;
        console.log(`[
            ${e[0]}, ${e[1]}, ${e[2]}
            ${e[4]}, ${e[5]}, ${e[6]}
            ${e[8]}, ${e[9]}, ${e[10]}
            ${e[12]}, ${e[13]}, ${e[14]}
            ]`);

        return this;
    };

    // default value
    this.identity();
};
