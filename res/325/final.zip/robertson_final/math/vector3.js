/**
 * represents a 3D Vector with x, y & z coordinates
 *
 * @param x the x coordinate (0 is default)
 * @param y the y coordinate (0 is default)
 * @param z the z coordinate (0 is default)
 * @constructor
 */
const Vector3 = function (x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;

    if (!(this instanceof Vector3)) {
        alert("Vector3 constructor must be called with the new operator");
    }

    if (this.x === undefined) {
        this.x = this.y = this.z = 0;
    }

    this.set = function (x, y, z) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    };

    /**
     * creates and returns a new Vector3 instance that is an exact copy of 'this'
     *
     * @returns {Vector3}
     */
    this.clone = function () {
        return new Vector3(this.x, this.y, this.z);
    };

    /**
     * copy the values from other into 'this'
     * @param other the Vector3 to copy values from
     * @returns {Vector3}
     */
    this.copy = function (other) {
        this.x = other.x;
        this.y = other.y;
        this.z = other.z;
        return this;
    };

    /**
     * add a vector to 'this' vector
     *
     * @param v
     * @returns {Vector3}
     */
    this.add = function (v) {
        this.x += v.x;
        this.y += v.y;
        this.z += v.z;
        return this;
    };

    /**
     * subtract a vector from 'this' vector
     * @param v
     * @returns {Vector3}
     */
    this.subtract = function (v) {
        this.x -= v.x;
        this.y -= v.y;
        this.z -= v.z;
        return this;
    };

    /**
     * multiplies this vector by -1, thereby negating it
     * @returns {Vector3}
     */
    this.negate = function () {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
        return this;
    };

    /**
     * multiplies this vector by a scalar value
     * @param scalar the multiplicand to apply to this vector
     * @returns {Vector3}
     */
    this.multiplyScalar = function (scalar) {
        this.x *= scalar;
        this.y *= scalar;
        this.z *= scalar;
        return this;
    };

    /**
     * @returns {number} the magnitude (AKA length) of 'this' vector
     */
    this.length = function () {
        return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
    };

    /**
     * @returns {number} the squared magnitude of this vector ||v||^2
     */
    this.lengthSqr = function () {
        return this.x * this.x + this.y * this.y + this.z * this.z;
    };

    /**
     * @returns {Vector3} a normalized clone of 'this' vector
     */
    this.normalized = function () {
        return new Vector3(this.x, this.y, this.z).multiplyScalar(1 / this.length());
    };

    /**
     * changes the components of this vector so that its magnitude will equal 1.
     *
     * @returns {Vector3}
     */
    this.normalize = function () {
        this.multiplyScalar(1 / this.length());
        return this;
    };

    /**
     * given another vector, calculate the dot product between between 'this' vector
     * and the 'other' vector
     *
     * @param other the 'other' vector to calculate the dot product from
     * @returns {number} the dot product between the vectors
     */
    this.dot = function (other) {
        return this.x * other.x + this.y * other.y + this.z * other.z;
    };

    /**
     * given another vector, calculate the cross product between 'this' vector
     * and the 'other' vector
     * @param other  other the 'other' vector to calculate the dot product from
     * @returns {Vector3} the dot product between the vectors
     */
    this.cross = function (other) {
        return new Vector3(
            this.y * other.z - this.z * other.y,
            this.z * other.x - this.x * other.z,
            this.x * other.y - this.y * other.x
        );
    }
};
