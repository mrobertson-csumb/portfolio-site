Matthew Robertson

1. What was your favorite topic or project in the course and why?

The raytracing was most interesting; its powerful stuff.
I'm awed at how cleanly the mathematical models translated into graphics without relying on a backing library.




2. If you could improve any aspect of this course, what would it be and why?

For the graphics pipeline topics, front-loading the overview and its various contexts might help comprehension.
Its a large and complex subject so getting oriented and knowing where we are on the map is important.

I liked the test-driven development aspect of some of the assignments;
 Adding unit tests to the graphical assignments (where relevant) would be welcome.
