function OrbitCamera() {
    this.cameraWorldMatrix = new Matrix4();
    this.cameraTarget = new Vector3();
    this.yawDegrees = 0;
    this.pitchDegrees = -40;
    this.minDistance = 25;
    this.maxDistance = 500;
    this.zoomScale = .4;
    const FARTHEST_ZOOM = 0.985;
    const NEAREST_ZOOM = 0.06;

    let lastMouseX = 0;
    let lastMouseY = 0;
    let isDragging = false;
    let position = new Vector3();

    this.getViewMatrix = () => this.cameraWorldMatrix.clone().inverse();

    this.update = () => {
        const tether = new Vector3(0, 0, this.minDistance + (this.maxDistance - this.minDistance) * this.zoomScale);
        const yaw = new Matrix3().setRotationY(this.yawDegrees);
        const pitch = new Matrix3().setRotationX(this.pitchDegrees);
        pitch.multiplyVector(tether);
        yaw.multiplyVector(tether);

        const fromTargetToCamera = this.cameraTarget.clone().add(tether);

        position = this.cameraTarget.clone().add(fromTargetToCamera);
        this.cameraWorldMatrix.setLookAt(position, new Vector3(), new Vector3(0, 1, 0));
    };

    //// wire event handlers
    document.onmousedown = evt => {
        isDragging = true;
        lastMouseX = evt.pageX;
        lastMouseY = evt.pageY;
    };

    document.onmousemove = evt => {
        if (isDragging) {
            this.yawDegrees -= (evt.pageX - lastMouseX) * 0.5;
            this.pitchDegrees -= (evt.pageY - lastMouseY) * 0.5;

            this.pitchDegrees = Math.min(this.pitchDegrees, 85);
            this.pitchDegrees = Math.max(this.pitchDegrees, -85);

            lastMouseX = evt.pageX;
            lastMouseY = evt.pageY;
        }
    };

    document.onmouseup = () => isDragging = false;

    // document.onmousewheel = ... // deprecated
    document.onwheel = evt => {
        const delta = this.zoomScale + (evt.deltaY * 0.005);

        // clamp zoom scale between nearest and farthest
        this.zoomScale = delta < NEAREST_ZOOM ? NEAREST_ZOOM
            : delta > FARTHEST_ZOOM ? FARTHEST_ZOOM
                : delta;
    };


}