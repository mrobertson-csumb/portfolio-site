const loadImage = function (url) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = function () {
            resolve(image);
        };
        image.onerror = function () {
            reject('Unable to load ' + url);
        };
        image.src = url;
    });
};
