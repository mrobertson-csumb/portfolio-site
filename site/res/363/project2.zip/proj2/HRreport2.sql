use a2_p2;
-- HRreport1 (2 view version)
DROP VIEW IF EXISTS hr2;

CREATE VIEW hr2 AS
    SELECT 
        `empid`,
        e.`name`,
        e.`salary`,
        d.`dept`,
        mn.`name` AS `manager_name`,
        mn.`salary` AS `manager_salary`
    FROM
        department d
            JOIN
        employee e ON d.`dept` = e.`dept`
            JOIN
        (SELECT 
            `name`, `mgr_id`, `salary`
        FROM
            employee e
        JOIN department d ON d.`dept` = e.`dept`
            AND d.`mgr_id` = e.`empid`) mn ON mn.`mgr_id` = d.`mgr_id`
    WHERE
        e.`salary` > mn.`salary`;



SELECT 
    `empid`,
    `name`,
    `salary`,
    `dept`,
    `manager_name`,
    `manager_salary`
FROM
    hr2;