--  load csv
use a2_p2;
drop table if exists employee;
drop table if exists department;
drop table if exists emp;

CREATE TABLE employee (
    empid INT PRIMARY KEY,
    name CHAR(20),
    dept INT,
    salary DOUBLE
);

CREATE TABLE department (
    dept INT PRIMARY KEY,
    dept_name CHAR(20),
    mgr_id INT
);

CREATE TABLE emp (
	empid int primary key,
    name char(20),
    dept int,
    salary double
);

LOAD DATA LOCAL INFILE '/_projects/[f-3] csumb-363/proj2/cst363ona/cst363ona/employee.data'
INTO TABLE employee
FIELDS TERMINATED BY ', '
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
(empid, name, dept, salary);

LOAD DATA LOCAL INFILE '/_projects/[f-3] csumb-363/proj2/cst363ona/cst363ona/department.data'
INTO TABLE department
FIELDS TERMINATED BY ', '
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
(dept, dept_name, mgr_id);


LOAD DATA LOCAL INFILE '/_projects/[f-3] csumb-363/proj2/cst363ona/cst363ona/emp.data'
INTO TABLE emp
FIELDS TERMINATED BY ', '
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
(empid, name, dept, salary);
