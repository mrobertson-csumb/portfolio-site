use a2_p2;
-- HRreport1 (2 view version)
DROP VIEW IF EXISTS hr_1vv;

CREATE VIEW hr_1vv AS
    SELECT 
        salary, m.dept, m.name
    FROM
        (SELECT 
            d.`dept`, `name`
        FROM
            department d
        JOIN employee e ON e.`dept` = d.`dept`
        WHERE
            e.`empid` = d.`mgr_id`) m
            JOIN
        (SELECT 
            `dept`, `salary`
        FROM
            employee) s ON m.`dept` = s.`dept`;


SELECT 
    `dept`,
    `name`,
    AVG(`salary`),
    MIN(`salary`),
    MAX(`salary`),
    COUNT(*)
FROM hr_1vv
GROUP BY `name`, `dept`