#! /bin/bash

trap "kill 0" SIGINT
python3 ./src/mpworker.py 8000 >> w8000.txt 2>&1 &
python3 ./src/mpworker.py 8001 >> w8001.txt 2>&1 &
python3 ./src/mpworker.py 8002 >> w8002.txt 2>&1 &
python3 ./src/mpworker.py 8003 >> w8003.txt 2>&1 &

# idle waiting for abort from user
read -r -d '' _ </dev/tty