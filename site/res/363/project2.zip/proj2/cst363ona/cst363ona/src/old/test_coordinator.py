import unittest
from old.coordinator import Coordinator


class TestCoordinator(unittest.TestCase):
    def setUp(self):
        self.c = Coordinator('../../config.txt', True)
        self.c.sendToAll('drop table if exists emp')
        self.c.sendToAll("create table emp (empid int primary key, name char(20), dept int, salary double)")
        self.c.loadTable("emp", "../../emp.data")

    def test_getRowByKey(self):
        # find by key
        for eid in range(1, 5):
            self.c.getRowByKey("select * from emp where empid=" + str(eid), eid)

        # find by non-key
        self.c.sendToAll("reduce select * from emp where dept=100 or salary > 100000 or name like '%7'")

        # --- map/shuffle/reduce example ---
        # create temp table
        self.c.sendToAll("drop table if exists tempdept ")
        self.c.sendToAll("create table tempdept (dept int, salary double)")

        # map -- run select & worker keep result
        self.c.sendToAll("map select dept, salary from emp ")

        # shuffle -- put map result on correct workers; {} is a placeholder
        self.c.sendToAll("shuffle insert into tempdept values {}")

        # reduce results & return to client
        actual = self.c.sendToAll("reduce "
                                  "select dept, avg(salary), count(*)"
                                  "from tempdept "
                                  "group by dept "
                                  "order by dept")

        # cleanup
        self.c.sendToAll("drop table if exists tempdept")

        self.c.close()

        print('a: %s' % actual)
        expect = [['100, 165446.76470588235, 17'],
                  ['104, 176500.84615384616, 13'],
                  ['101, 171337.66666666666, 18'],
                  ['105, 171256.05555555556, 18'],
                  ['102, 160396.875, 16'],
                  ['103, 174414.0, 17']]

        self.assertEqual(expect, actual)
