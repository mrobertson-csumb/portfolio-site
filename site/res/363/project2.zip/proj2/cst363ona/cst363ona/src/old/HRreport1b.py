# from coordinator import Coordinator
from mpclient import Coordinator
from mpclient import readConfig


class Subquery(object):
    template_drop = 'DROP TABLE IF EXISTS temp_%s'

    template_create = 'CREATE TABLE temp_%s (%s)'

    template_insert = 'INSERT INTO temp_%s  VALUES {}'

    def __init__(self, name, schema_fields, query, ):
        self.name = name
        self.drop = self.template_drop % name
        self.create = self.template_create % (name, schema_fields)
        self.query = query
        self.insert = self.template_insert % name

    def run(self, coordinator):
        print('drop temp_%s -- %s' % (self.name, self.drop))
        coordinator.sendToAll(self.drop)

        print('create temp_%s -- %s' % (self.name, self.create))
        coordinator.sendToAll(self.create)

        print('query %s -- %s' % (self.name, self.query))
        coordinator.sendToAll('map ' + self.query)
        print('insert %s -> temp_%s -- %s' % (self.name, self.name, self.insert))
        coordinator.sendToAll('shuffle ' + self.insert)

    def cleanup(self, coordinator):
        print('cleanup temp_%s -- %s' % self.name, self.drop)
        coordinator.sendToAll(self.drop)


# get department_id, department_manager, average, min, max salary of employees in department
# number of employees in department
def main():
    readConfig('../config.txt')
    dp = Subquery(
        'dp',
        'dept INT, salary INT',
        '''
        SELECT dept, salary
        FROM employee;
        '''
    )

    mn = Subquery(
        'mn',
        'dept INT PRIMARY KEY, name CHAR(20)',
        '''
        SELECT d.`dept`, e.`name`
        FROM department d
        JOIN employee e ON e.`dept` = d.`dept`
        WHERE e.`empid` = d.`mgr_id`;
        '''
    )

    # select t1.dept, name, avg(salary), min(salary), max(salary), count(*)
    summarize = '''
    SELECT 
        d.`dept`,
        m.`name`,
        AVG(d.`salary`),
        MIN(d.`salary`),
        MAX(d.`salary`),
        COUNT(*)
    FROM
        temp_dp d
            JOIN
        temp_mn m ON d.`dept` = m.`dept`
    GROUP BY d.`dept` , m.`name`;
    '''

    c = Coordinator()
    # c = Coordinator('../config.txt', True)

    dp.run(c)
    mn.run(c)

    print('reduce')
    result = c.sendToAll('reduce ' + summarize)
    # print('result: %s' % len(result))

    # cleanup temp tables
    # print('cleanup')
    # c.sendToAll(drop)

    c.close()


main()
