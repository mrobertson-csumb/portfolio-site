from old.coordinator import Coordinator
import random


def main():
    # create files for test data
    file_emp = open('../employee.data', 'w')
    file_dept = open('../department.data', 'w')

    for dept in range(1, 1001):
        empid = dept * 2
        name = 'John Manager %s' % dept
        dept_name = 'Dept #%s' % dept
        salary = random.randint(100000, 150000)
        dpt_line = '%s, "%s", %s' % (dept, dept_name, empid)
        emp_line = '%s, "%s", %s, %s' % (empid, name, dept, salary)
        if dept > 1:
            dpt_line = '\n' + dpt_line
            emp_line = '\n' + emp_line

        file_dept.write(dpt_line)
        file_emp.write(emp_line)

    file_dept.close()

    for empid in range(3000, 53000):
        name = 'Joe Employee %s' % empid
        dept = random.randint(1, 1000)
        salary = random.randint(60000, 250000)
        line = '\n%s, "%s", %s, %s' % (empid, name, dept, salary)

        file_emp.write(line)

    file_emp.close()

    c = Coordinator('../config.txt')

    c.sendToAll("drop table if exists employee")
    c.sendToAll("drop table if exists department")

    c.sendToAll("create table department (dept int primary key, dept_name char(20), mgr_id int)")
    c.sendToAll("create table employee (empid int primary key, name char(20), dept int, salary double)")
    print("Loading employee table.  This will take a few minutes.")
    c.loadTable("employee", "../employee.data")
    print("Loading department table")
    c.loadTable("department", "../department.data")
    c.close()


main()
