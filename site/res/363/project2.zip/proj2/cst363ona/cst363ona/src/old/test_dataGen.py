import unittest
from old.mpclient1 import DataGen


class TestDataGen(unittest.TestCase):
    def student_check(self, subject):
        sid, maj, gpa = subject
        self.assertGreaterEqual(sid, 1)
        self.assertLessEqual(sid, 9999)
        self.assertIn(maj, ['Biology', 'Business', 'CS', 'Statistics'])
        self.assertGreaterEqual(gpa, 2.5)
        self.assertLessEqual(gpa, 4.0)

    def test_gen_student(self):
        subject = DataGen.gen_student()
        self.student_check(subject)

    def test_populate_student_data(self):
        dg_data = DataGen(100).data

        for item in dg_data:
            maj, gpa = dg_data[item]
            subject = (item, maj, gpa)
            self.student_check(subject)

    def test_export_to_file(self):
        DataGen(100).export_to_file('test.txt')
