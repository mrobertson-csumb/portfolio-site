from old.coordinator import Coordinator


# list employees who earn more than their manager
# eid, name, salary, dept, manager name, manager salary
def main():
    query = '''
    SELECT 
        `empid` AS `empid`,
        e.`name` AS `name`,
        e.`salary` AS `salary`,
        d.`dept` AS `dept`,
        mn.`name` AS `manager_name`,
        mn.`salary` AS `manager_salary`
    FROM
        department d
            JOIN
        employee e ON d.`dept` = e.`dept`
            JOIN
        (SELECT 
            `name`, `mgr_id`, `salary`
        FROM
            employee e
        JOIN department d ON d.`dept` = e.`dept`
            AND d.`mgr_id` = e.`empid`) mn ON mn.`mgr_id` = d.`mgr_id`
    WHERE
        e.`salary` > mn.`salary`
    '''

    # drop = '''DROP TABLE IF EXISTS temp_table'''

    # create = '''
    # CREATE TABLE temp_table (
    #     empid INT PRIMARY KEY,
    #     dept INT,
    #     manager_name CHAR(20),
    #     salary INT
    # );
    # '''

    summarize = '''
    SELECT
        dept,
        manager_name,
        AVG(salary),
        MIN(salary),
        MAX(salary),
        COUNT(*)
    FROM
        temp_table
    GROUP BY dept , manager_name;
    # '''

    c = Coordinator('../config.txt', True)

    # prep temp table
    # print('drop')
    # c.sendToAll(drop)
    #
    # print('create')
    # c.sendToAll(create)

    # first query
    print('query: %s' % query)
    result = c.sendToAll('reduce ' + query)
    print('results: %s' % len(result))

    # print('shuffle')
    # c.sendToAll("shuffle INSERT INTO temp_table VALUES {}")
    #
    # print('reduce')
    # c.sendToAll('reduce ' + summarize)
    #
    # # cleanup temp table
    # print('cleanup')
    # c.sendToAll(drop)

    c.close()


main()
