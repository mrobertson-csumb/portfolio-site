import random
import string
from old.coordinator import Coordinator


class DataGen(object):
    def __init__(self, number_to_generate=100):
        self.data = dict()
        self.gen_number = number_to_generate
        self.populate_student_data()

    @staticmethod
    def gen_student():
        # id -- random int
        student_id = random.randint(1, 9999)  # will use dict to ensure no-dupes

        # name
        student_name = ''.join(random.choice(string.ascii_uppercase) for _ in range(5)).capitalize()

        # major -- random among: Biology, Business, CS, Statistics
        major = random.choice(['Biology', 'Business', 'CS', 'Statistics'])

        # gpa -- random from 2.5 to 4.0
        gpa = random.randint(25, 40) / 10
        return student_id, student_name, major, gpa

    def populate_student_data(self):
        while len(self.data) < self.gen_number:
            student_id, student_name, major, gpa = self.gen_student()

            self.data[student_id] = (student_name, major, gpa)

    def export_to_file(self, filename):
        f = open(filename, 'w')
        for i, student_id in enumerate(self.data):
            name, major, gpa = self.data[student_id]
            line = '%s, "%s", "%s", %s' % (student_id, name, major, gpa)
            if i > 0:
                line = '\n' + line
            f.write(line)
        f.close()


def main():
    c = Coordinator('../config.txt')

    # create student table on all nodes
    c.sendToAll("drop table if exists student")
    c.sendToAll("create table student (id int primary key, name char(20), major char(10), gpa double)")

    # generate 100 rows of (random) test data into a file
    dg = DataGen(100)
    dg.export_to_file('../student.data')

    # load from the file into the database
    c.loadTable("student", "../student.data")

    # verify cluster is working with queries
    id1 = next(iter(dg.data))
    print('student with id: %s' % id1)
    q_existing_id = "select * from student where id = %s" % id1
    c.getRowByKey('reduce ' + q_existing_id, id1)

    id2 = 0000
    print('student with id: %s' % id2)
    q_non_existent_id = "select * from student where id = %s" % id2
    c.getRowByKey('reduce ' + q_non_existent_id, id2)

    major = 'Biology'
    print('students with major: %s' % major)
    q_bio_majors = "select * from student where major = '%s'" % major
    c.sendToAll('reduce ' + q_bio_majors)

    gpa = '3.2'
    print('students with gpa >= %s' % gpa)
    q_b_or_better = "select * from student where gpa >= %s" % gpa
    c.sendToAll('reduce ' + q_b_or_better)

    c.close()


main()
