class PlainLoad(object):
    def loadTable(self, table_name, filename):
        f = open(filename, 'r')
        for line in f:
            line = line.strip()
            sql = 'insert into ' + table_name + ' values(' + line + ')'
            int_key = line[0: line.index(',')]
            # print('key: %s, sql: %s' % (int_key, sql))
            snd, rec = self.query_target(sql, int_key)

            if self.debug:
                print('sent: %s, received: %s' % (sql, rec))
        f.close()
