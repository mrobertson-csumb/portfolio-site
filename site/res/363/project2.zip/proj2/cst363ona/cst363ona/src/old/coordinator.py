import socket


class Connection(object):
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.socket = None


class Coordinator(object):
    def __init__(self, config_file='config.txt', debug=False):
        self.userid = ''
        self.password = ''
        self.debug = debug
        self.connections = []

        # load config
        f = open(config_file)
        for line in f:
            tokens = line.split()
            if tokens[0] == 'userid':
                self.userid = tokens[1]
            elif tokens[0] == 'password':
                self.password = tokens[1]
            elif tokens[0] == 'worker':
                self.connections.append(Connection(tokens[1], int(tokens[2])))
            elif tokens[0] == 'debug':
                self.debug = int(tokens[1])
            else:
                print("configuration file error", line)
        f.close()

        # connect to workers
        for c in self.connections:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((c.host, c.port))
            c.socket = sock
            if self.debug:
                print("Connected to", str(c))

    def close(self):
        for c in self.connections:
            c.socket.close()
        self.connections = []
        if self.debug:
            print("All worker connections closed")

    def send(self, sock, msg):
        buffer = bytes(msg, 'utf-8') + b'\x00'
        start = 0
        while start < len(buffer):
            sent_bytes = sock.send(buffer[start:])
            if sent_bytes == 0:
                print("connection error", sock)
                return -1
            start = start + sent_bytes
        if self.debug:
            print("send msg=", msg)
        return 0

    def recv(self, sock):
        buffer = b''
        while True:
            chunk = sock.recv(2048)
            if len(chunk) == 0:
                print('connection error', sock)
                return -1
            buffer = buffer + chunk
            if buffer[-1] == 0:
                return buffer[0:-1].decode('utf-8')

    def sendToAll(self, stmt):
        for c in self.connections:
            self.send(c.socket, stmt)
            if self.debug:
                print("to port=", c.port, "msg=", stmt)

        results = []

        for c in self.connections:
            received = self.recv(c.socket)
            if self.debug:
                print("from port=", c.port, "msg=", received)

            # received a set of rows -> print one row per line
            # remove leading ( & trailing ); split records
            received = str(received).strip()[1:-1].split(')(')
            for result in received:
                if result:
                    result = result.split(', ')
                    results.append(result)

            if results:
                print(results)
        return results

    def getRowByKey(self, sql, key):
        snd, rec = self.query_target(sql, key)
        print("getRowByKey data=", rec)

    def loadTable(self, table_name, filename):
        # csv file (with schema); 1st column (int key)
        # contents are hashed & distributed across worker nodes
        f = open(filename, 'r')
        for line in f:
            line = line.strip()
            sql = 'insert into ' + table_name + ' values(' + line + ')'
            int_key = line[0: line.index(',')]
            # print('key: %s, sql: %s' % (int_key, sql))
            snd, rec = self.query_target(sql, int_key)

            if self.debug:
                print('sent: %s, received: %s' % (sql, rec))
        f.close()

    def query_target(self, sql, key):
        index = hash(int(key)) % len(self.connections)
        # print('query_target -- db#: %s, key: %s, sql: %s ' % (index, key, sql))
        sock = self.connections[index].socket
        snd = self.send(sock, sql)
        rec = self.recv(sock)
        return snd, rec
