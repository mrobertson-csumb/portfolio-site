from old.coordinator import Coordinator


# get department_id, department_manager, average, min, max salary of employees in department
# number of employees in department
def main():
    query = '''
    SELECT
        e.`empid` as `empid`,
        d.`dept` as `dept`,
        mn.`name` as `manager_name`,
        e.`salary` as `salary`
    FROM
        department d
            JOIN
        employee e ON d.`dept` = e.`dept`
            JOIN
        (SELECT 
            `name`, `mgr_id`
        FROM
            employee e
        JOIN department d ON d.`dept` = e.`dept`
            AND d.`mgr_id` = e.`empid`) mn ON mn.`mgr_id` = d.`mgr_id`
    '''

    drop = '''DROP TABLE IF EXISTS temp_table'''

    create = '''
    CREATE TABLE temp_table (
        empid INT PRIMARY KEY,
        dept INT,
        manager_name CHAR(20),
        salary INT
    );
    '''

    summarize = '''
    SELECT 
        dept,
        manager_name,
        AVG(salary),
        MIN(salary),
        MAX(salary),
        COUNT(*)
    FROM
        temp_table
    GROUP BY dept , manager_name;
    '''

    c = Coordinator('../config.txt', True)

    # prep temp table
    print('drop')
    c.sendToAll(drop)

    print('create')
    c.sendToAll(create)

    # first query
    print('query: %s' % query)
    c.sendToAll('map ' + query)

    print('shuffle')
    c.sendToAll("shuffle INSERT INTO temp_table  VALUES {}")

    print('reduce')
    result = c.sendToAll('reduce ' + summarize)
    print('result: %s' % len(result))

    # cleanup temp table
    print('cleanup')
    # c.sendToAll(drop)

    c.close()


main()
