use a2_p2;
-- HRreport1 (2 view version)
DROP VIEW IF EXISTS hr_2vv_man;
DROP VIEW IF EXISTS hr_2vv_sal;

CREATE VIEW hr_2vv_man AS
    SELECT 
        d.`dept`, `name`
    FROM
        department d
            JOIN
        employee e ON e.`dept` = d.`dept`
    WHERE
        e.`empid` = d.`mgr_id`;

CREATE VIEW hr_2vv_sal AS
    SELECT 
        `dept`, `salary`
    FROM
        employee;

select * from hr_2vv_sal;

SELECT 
    s.`dept`,
    `name`,
    AVG(`salary`),
    MIN(`salary`),
    MAX(`salary`),
    COUNT(*)
FROM
    hr_2vv_sal s
        JOIN
    hr_2vv_man m ON s.`dept` = m.`dept`
GROUP BY `name`, s.`dept`