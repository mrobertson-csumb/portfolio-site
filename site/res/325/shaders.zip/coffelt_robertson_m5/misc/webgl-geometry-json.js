/**
 * A simple object to encapsulate the data and operations of object rasterization
 * loads data from a JSON file and renders
 *
 * modified for steps 6, 9, B1
 *
 * @author John Coffelt
 * @author Matthew Robertson
 */
function WebGLGeometryJSON(gl) {
    this.gl = gl;
    this.worldMatrix = new Matrix4();
    this.alpha = 1;

    this.START = Date.now();

    /**
     * Get this object's position
     * intended to aid the painter's algorithm
     *
     * modified
     */
    this.getPosition = function () {
        const e = this.worldMatrix.elements;
        // see: https://computergraphics.stackexchange.com/a/1978
        return new Vector3(e[3], e[7], e[11]).normalize();
    };

    // -----------------------------------------------------------------------------
    this.create = function (jsonFileData, rawImage) {
        // fish out references to relevant data pieces from 'data'
        var verts = jsonFileData.meshes[0].vertices;
        var normals = jsonFileData.meshes[0].normals;
        var texcoords = jsonFileData.meshes[0].texturecoords[0];
        var indices = [].concat.apply([], jsonFileData.meshes[0].faces);

        // create the position and color information for this object and send it to the GPU
        this.vertexBuffer = gl.createBuffer();
        this.gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
        this.gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(verts), gl.STATIC_DRAW);

        this.normalBuffer = this.gl.createBuffer();
        this.gl.bindBuffer(gl.ARRAY_BUFFER, this.normalBuffer);
        this.gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);

        this.texcoordBuffer = this.gl.createBuffer();
        this.gl.bindBuffer(gl.ARRAY_BUFFER, this.texcoordBuffer);
        this.gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(texcoords), gl.STATIC_DRAW);

        this.indexBuffer = this.gl.createBuffer();
        this.gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
        this.gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), gl.STATIC_DRAW);

        // store all of the necessary indexes into the buffer for rendering later
        this.indexCount = indices.length;

        if (rawImage) {
            // #6 setup texturing for spheres
            // #6.1 create the texture
            this.texture = gl.createTexture();

            // #6.2 bind the texture
            this.gl.bindTexture(gl.TEXTURE_2D, this.texture);

            // needed for the way browsers load images, ignore this
            this.gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

            // #6.3 set wrap modes (for s and t) for the texture
            this.gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
            this.gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);

            // #6.4 set filtering modes (magnification and minification)
            this.gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            this.gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

            // #6.5 send the image WebGL to use as this texture
            gl.texImage2D(
                gl.TEXTURE_2D,
                0,                // level
                gl.RGBA,          // internal format
                gl.RGBA,          // source format
                gl.UNSIGNED_BYTE, // source type
                rawImage          // image
            );

            // We're done for now, unbind
            this.gl.bindTexture(gl.TEXTURE_2D, null);
        }
    };

    // -------------------------------------------------------------------------
    this.render = function (camera, projectionMatrix, shaderProgram) {
        gl.useProgram(shaderProgram);

        var attributes = shaderProgram.attributes;
        var uniforms = shaderProgram.uniforms;

        gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
        gl.vertexAttribPointer(
            attributes.vertexPositionAttribute,
            3,
            gl.FLOAT,
            gl.FALSE,
            0,
            0
        );
        gl.enableVertexAttribArray(attributes.vertexPositionAttribute);

        if (attributes.hasOwnProperty('vertexNormalsAttribute')) {
            gl.bindBuffer(gl.ARRAY_BUFFER, this.normalBuffer);
            gl.vertexAttribPointer(
                attributes.vertexNormalsAttribute,
                3,
                gl.FLOAT,
                gl.FALSE,
                0,
                0
            );
            gl.enableVertexAttribArray(attributes.vertexNormalsAttribute);
        }

        if (attributes.hasOwnProperty('vertexTexcoordsAttribute')) {
            gl.bindBuffer(gl.ARRAY_BUFFER, this.texcoordBuffer);
            gl.vertexAttribPointer(
                attributes.vertexTexcoordsAttribute,
                2,
                gl.FLOAT,
                gl.FALSE,
                0,
                0
            );
            gl.enableVertexAttribArray(attributes.vertexTexcoordsAttribute);
        }

        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);


        if (this.texture) {
            // #6.6 ensure texture is bound to the correct slot
            gl.activeTexture(gl.TEXTURE0);
            gl.bindTexture(gl.TEXTURE_2D, this.texture);
        }

        // Send our matrices to the shader
        gl.uniformMatrix4fv(
            uniforms.worldMatrixUniform,
            false,
            this.worldMatrix.clone().transpose().elements
        );

        gl.uniformMatrix4fv(
            uniforms.viewMatrixUniform,
            false,
            camera.getViewMatrix().clone().transpose().elements
        );

        gl.uniformMatrix4fv(
            uniforms.projectionMatrixUniform,
            false,
            projectionMatrix.clone().transpose().elements
        );

        gl.uniform1f(uniforms.alphaUniform, this.alpha);
        // #B1
        let elapsed = (Date.now() - this.START) / 7500;

        gl.uniform1f(uniforms.timeUniform, elapsed);

        gl.drawElements(
            gl.TRIANGLES,
            this.indexCount,
            gl.UNSIGNED_SHORT,
            0
        );

        this.texture && gl.bindTexture(gl.TEXTURE_2D, null);
        gl.disableVertexAttribArray(attributes.vertexPositionAttribute);
        attributes.vertexNormalsAttribute && gl.disableVertexAttribArray(attributes.vertexNormalsAttribute);
        attributes.vertexTexcoordsAttribute && gl.disableVertexAttribArray(attributes.vertexTexcoordsAttribute);
    }
}